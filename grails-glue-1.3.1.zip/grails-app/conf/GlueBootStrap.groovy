import com.bensmann.glue.service.*

/**
 * 
 */
class GlueBootStrap {
	
	def init = { servletContext ->
		println "GlueBootStrap.init"
	}
	
	def destroy = {
	}
	
}
