package com.bensmann.glue

/**
 * 
 */
class GlueGrailsService {
	
	/**
	 * The scope. See http://www.grails.org/Services.
	 */
	def scope = "singleton" // prototype request flash flow conversation session singleton
	
	/**
	 * Transactional?
	 */
	boolean transactional = false
	
	/**
	 * 
	 */
	private def getService(name) {
		def service = grailsApplication.mainContext.getBean(name)
		if (!service) {
			log.error "getService: Cannot find service ${name}"
		}
		println "getService: name=${name} -> ${service}"
		service
	}
	
	/**
	 * 
	 */
	def methodMissing(String name, args) {
		def what = name.split("_")
		println "methodMissing: what=${what}"
		// grailsService.call(service, method, args)
		if (what[0] == "call" && args.length > 2) {
			println "methodMissing: calling getService(${args[0]})?.'${args[1]}'(${args[2]})"
			getService(args[0])?."${args[1]}"(args[2])
		}
		// grailsService.call_aMethod_from_otherService(args)
		else if (what[0] == "call" && what[2] == "from" && what.length == 4) {
			def method = what[1]
			def service = what[3]
			println "methodMissing: calling getService(${service})?.'${method}'(${args})"
			getService(service)?."${method}"(args)
		} else {
			log.error "methodMissing: Don't know what to do: name=${name}, args=${args}"
		}
	}
	
}
