package com.bensmann.glue

/**
 * 
 */
class GlueControllerService {
	
	/**
	 * The scope. See http://www.grails.org/Services.
	 */
	def scope = "singleton" // prototype request flash flow conversation session singleton
	
	/**
	 * Transactional?
	 */
	boolean transactional = false
	
	/**
	 * 
	 */
	def glueMimeTypeService
	
	/**
	 * Stream a file to client. Writes to HTTP resonse.
	 * @param arg Map: response, bytes, name, [mimeType, contentDisposition]
	 */
	def stream(arg) {
		// Content type and length
		arg.response.contentType = arg.mimeType ?: glueMimeTypeService.getMimeType(arg.name)
		arg.response.contentLength = arg.bytes.size()
		// Content disposition
		arg.response.setHeader("Content-disposition", "${arg.contentDisposition ?: "attachment"};filename=${arg.name}")
		// Stream bytes
		arg.response.outputStream << new ByteArrayInputStream(arg.bytes)
		// Flush stream
		arg.response.outputStream.flush()
	}
	
}