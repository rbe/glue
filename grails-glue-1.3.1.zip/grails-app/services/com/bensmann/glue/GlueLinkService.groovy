package com.bensmann.glue

import org.codehaus.groovy.grails.web.taglib.GroovyPageTagBody
import org.springframework.beans.factory.InitializingBean

/**
 * 
 */
class GlueLinkService implements InitializingBean {
	
	/**
	 * The scope. See http://www.grails.org/Services.
	 */
	def scope = "singleton" // prototype request flash flow conversation session singleton
	
	/**
	 * Transactional?
	 */
	boolean transactional = false
	
	/**
	 * 
	 */
	def grailsApplication
	
	/**
	 * The GSP tag library.
	 */
	def gspTagLibraryLookup
	
	/**
	 * The g tag library.
	 */
	def g
	
	/**
	 * 
	 */
	def glueDomainClassService
	
	/**
	 * InitializingBean.
	 */
	void afterPropertiesSet() {
		g = gspTagLibraryLookup.lookupNamespaceDispatcher("g")
	}
	
	//
	// DOMAIN CLASSES
	//
	
	/**
	 * Create a link to edit a domain instance.
	 */
	def editLink(arg) {
		if (log.traceEnabled) log.trace "editLink: arg=${arg.inspect()}"
		def params = [
			domain: glueDomainClassService.getName(arg.domain),
			domainId: arg.domainId,
			type: arg.type,
			mode: "edit",
			update_success: arg.update?.success,
			update_failure: arg.update?.failure,
		]
		if (arg.prevDomain) {
			params.nextAction_controller = "glue"
			params.nextAction_action = "renderAssociation"
			params.nextAction_params = "domain=${arg.prevDomain}&domainId=${arg.prevDomainId}&property=${arg.prevProperty}"
			
		}
		// TODO Check generation of text when no body is given
		def link = g.remoteLink(
			controller: "glue",
			action: "edit",
			params: params,
			update: arg.update,
			class: arg.editLinkClass ?: "crud_assoc_links_edit"
		) { arg.body/*?.class == GroovyPageTagBody*/ ? arg.body() : "Edit #${arg.domainId}" }
		if (log.traceEnabled) log.trace "editLink(${arg.inspect()}): link=${link}"
		link
	}
	
	/**
	 * Create a link to delete this association.
	 */
	def dissociateLink(arg) {
		if (log.traceEnabled) log.trace "dissociateLink: ${arg.inspect()}"
		g.remoteLink(
			controller: "glue",
			action: "dissociate",
			params: [
				domainA: glueDomainClassService.getName(arg.domainA), idA: arg.idA,
				propertyA: arg.propertyA,
				domainB:  glueDomainClassService.getName(arg.domainB), idB: arg.idB,
				mode: arg.mode,
				type: arg.type,
				update_success: arg.update?.success,
				update_failure: arg.update?.failure
			],
			update: arg.update,
			class: "crud_assoc_links_remove"
		) { arg.body ? arg.body() : "<img class='crud_assoc_links_remove_button' src='${g.resource(dir: 'images', file: 'picture_remove.png')}' alt='Remove association' />" }
	}
	
}
