package com.bensmann.glue

import com.bensmann.cdm.project.*

/**
 * This service reads Odisee definitions from domain instances and submits them to Odisee
 * for generating a document.
 */
class GlueOdiseeService {
	
	/**
	 * The scope. See http://www.grails.org/Services.
	 */
	def scope = "singleton" // prototype request flash flow conversation session singleton
	
	/**
	 * Transactional?
	 */
	boolean transactional = false
	
	/**
	 * 
	 */
	def glueDomainClassService
	
	/**
	 * 
	 */
	def getOdiseeRequest(arg) {
		if (log.traceEnabled) log.trace "getOdiseeRequest: arg=${arg.inspect()}"
		def r
		def inst = glueDomainClassService.getInstance(domain: arg.domain, id: arg.domainId)
		if (inst) {
			try {
				def xml = new GlueBuilder().bind { mkp.yield inst.odiseeRequest }
				println/*if (log.debugEnabled) log.debug*/ "getOdiseeRequest: Odisee request for ${inst}: ${xml.toString()}"
				// TODO Rename to odiseeService
				def odisee = grailsApplication.mainContext.getBean("oooService")
				r = odisee.generateDocument(xml: xml.toString())
			} catch (e) {
				log.error "show: Could not process Odisee configuration of ${inst}: ${e}"
				throw e
			}
		} else {
			log.error "getOdiseeRequest(${arg.inspect()}): No instance found"
		}
		r
	}
	
}
