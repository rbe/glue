package com.bensmann.glue

import org.springframework.beans.factory.InitializingBean

/**
 * 
 */
class GlueFileService implements InitializingBean {
	
	/**
	 * The scope. See http://www.grails.org/Services.
	 */
	def scope = "prototype" // prototype request flash flow conversation session singleton
	
	/**
	 * Transactional?
	 */
	boolean transactional = true
	
	/**
	 * 
	 */
	def grailsApplication
	
	/**
	 * 
	 */
	def glueNameService
	
	/**
	 * 
	 */
	def glueControllerService
	
	/**
	 * 
	 */
	def glueDomainClassService
	
	/**
	 * 
	 */
	def glueMimeTypeService
	
	/**
	 * InitializingBean.
	 */
	void afterPropertiesSet() {
	}
	
	//
	// FILE UPLOAD
	//
	
	/**
	 * Save a BLOB in a property of a domain instance.
	 */
	def saveBlob(arg) {
		def inst = glueDomainClassService.getInstance(domain: arg.domain, id: arg.domainId.toLong())
		if (inst) {
			// Set properties if defined only
			try {
				inst."${arg.property}OriginalFilename" = arg.data.filename
				inst."${arg.property}MimeType" = arg.data.mimeType
			} catch (e) {
				log.warn "saveBlob: Cannot set original filename or mime type for ${arg.property}: ${e}"
			}
			// TODO One-to-many: use glueCrudService.associate!
			inst."${arg.property}" = glueDomainClassService.toBlob(arg.data.content)
			inst.validate()
			inst.save()
			log.info "Saved file ${arg.data.filename} length=${arg.data.content.length} to ${arg.domain}#${arg.domainId}.${arg.property}"
		} else {
			log.warn "Could not find instance of ${arg.domain}#${arg.domainId} for saving file upload ${arg.data.filename}"
		}
	}
	
	/**
	 * Convert controller parameters for file uploads into a map.
	 * Parameter must be named gxupload_<domain with number sign>_<property>_<id>.
	 */
	def upload(arg) {
		// Map with file names and their contents
		def map = [:]
		arg.params.each { k, v ->
			// Get file
			def file = v
			if (!file?.isEmpty()) {
				// Get mime type
				def mimeType = glueMimeTypeService.getMimeType(name: file.originalFilename)
				// Save text or bytes
				saveBlob(
					domain: glueNameService.getDomainClassPart(k),
					domainId: glueNameService.getIdPart(k),
					property: glueNameService.getPropertyPart(k),
					data: [
						content: mimeType?.browser?.startsWith("text") ? file.text : file.bytes,
						filename: file.originalFilename,
						mimeType: mimeType
					]
				)
				//f.transferTo(new File('someotherloc'))
			} else {
				log.warn "upload: File ${k} is empty, skipping"
			}
		}
		map
	}
	
}
