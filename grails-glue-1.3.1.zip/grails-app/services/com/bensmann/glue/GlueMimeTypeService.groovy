package com.bensmann.glue

import org.springframework.beans.factory.InitializingBean

/**
 * 
 */
class GlueMimeTypeService implements InitializingBean {
	
	/**
	 * The scope. See http://www.grails.org/Services.
	 */
	def scope = "singleton" // prototype request flash flow conversation session singleton
	
	/**
	 * Transactional?
	 */
	boolean transactional = false
	
	/**
	 * 
	 */
	void afterPropertiesSet() {
	}
	
	/**
	 * Determine mime type.
	 * @param arg Map: name: a name, e.g. a filename
	 */
	def getMimeType(arg) {
		def mimeType
		// Filename with extension?
		if (arg.name.indexOf(".") > -1) {
			def ext = arg.name.split("\\.").toList().last()
			mimeType = GlueMimeType.findByExtension(ext)
		} else {
			mimeType = GlueMimeType.findByNameOrExtensionOrBrowser(arg.name, arg.name, arg.name)
		}
		if (!mimeType) {
			mimeType = GlueMimeType.findByName("Unknown")
			log.warn "Could not recognize mime type of ${arg.name}; using ${mimeType}"
		} else {
			if (log.traceEnabled) log.trace "Mime type for ${arg.name} is ${mimeType}"
		}
		mimeType
	}
	
}