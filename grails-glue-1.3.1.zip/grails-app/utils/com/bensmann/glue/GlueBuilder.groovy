package com.bensmann.glue

import groovy.util.BuilderSupport
import groovy.xml.MarkupBuilder
import groovy.xml.StreamingMarkupBuilder

/**
 * 
 */
class GlueBuilder extends StreamingMarkupBuilder {
	
	/*
	protected void setParent(Object parent, Object child) {
		println "\nsetParent: ${parent?.name()} <- ${child?.name()}"
		if (child && parent) {
			parent.append(child)
		}
	}
	
	protected Object createNode(Object name) {
		createNode name, [:], null
	}
	
	protected Object createNode(Object name, Object value) {
		createNode name, [:], value
	}
	
	protected Object createNode(Object name, Map attributes) {
		createNode name, attributes, null
	}
	
	protected Object createNode(Object name, Map attributes, Object value) {
		println "createNode(name, attributes, value): ${name}, ${attributes}, ${value}"
		def parentName = getCurrentNode()?.parent()?.name()
		println "createNode(name, attributes, value): my parent is actually: ${parentName}"
		return new Node(getCurrentNode(), name, attributes, value)
	}
	
	protected Node getCurrentNode() {
		return (Node) getCurrent()
	}
	*/
	
	/*
	static def showNode(node) {
		def iter = node.iterator()
		while (iter.hasNext()) {
			def o = iter.next()
			println "${o?.getClass()} -> ${o?.name()}  ${o?.attributes()}"
		}
	}
	
	static void main(String[] args) {
		showNode(x)
		println "\n\n"
		def domain0 = x.get("domain")[0]
		showNode(domain0)
		println domain0.get("property")[0].get("render")[0].children()
		g.properties.each { println it }
		g.metaClass.methods.each { println it.name }
	}
	*/
	
}
