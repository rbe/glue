package com.bensmann.glue

import grails.persistence.Event

/**
 * Constants for glue.
 */
class GlueConstants {
	
	/**
	 * Properties to skip when dealing with domain classes.
	 */
	def static excludedProperties =
			Event.allEvents.toList() <<
			'version' <<
			'dateCreated' << 'lastUpdated' <<
			'dirty'
	
}
