package com.bensmann.glue

/**
 * 
 */
class GlueWidgetTestCategory {
	
	def static equals(Integer self, Integer a) {
		if (self == a) {
			true
		} else {
			false
		}
	}
	
	def static equals(Long self, Long a) {
		if (self == a) {
			true
		} else {
			false
		}
	}
	
	def static moreThan(Integer self, Integer a) {
		if (self > a) {
			true
		} else {
			false
		}
	}
	
	def static moreThan(Long self, Long a) {
		if (self > a) {
			true
		} else {
			false
		}
	}
	
	def static lessThan(Integer self, Integer a) {
		if (self < a) {
			true
		} else {
			false
		}
	}
	
	def static lessThan(Long self, Long a) {
		if (self < a) {
			true
		} else {
			false
		}
	}
	
}