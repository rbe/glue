package com.bensmann.glue

import org.codehaus.groovy.grails.scaffolding.DomainClassPropertyComparator

/**
 * Helper for Grails + Glue scaffolding.
 */
class GlueScaffolder {
	
	/**
	 * Return all persistent properties of a domain class used in scaffolding:
	 * properties are persistent and should be display.
	 * @param arg Map: domainClass = DefaultGrailsDomainClass
	 * @return Sorted list of properties (according to domain class constraints)
	 */
	def static getProperties(arg) {
		def props = arg.domainClass?.properties.grep { !GlueConstants.excludedProperties.contains(it.name) }.findAll {
			(it.name == "id") || arg.domainClass.constrainedProperties[it.name]?.display
		} as List
		def comp = new DomainClassPropertyComparator(arg.domainClass) as java.util.Comparator
		Collections.sort(props, comp)
		props
	}
	
	/**
	 * Generate map for Grails UI datatable tag.
	 */
	def static getGrailsUiDataTableCols(arg) {
		def dataTableCols = []
		GlueScaffolder.getProperties(domainClass: arg.domainClass).each { p ->
			// TODO cp = domainClass.constrainedProperties[p.name] ... !cp.widget == "richtext"
			if (p.isAssociation() || (p.type in [java.sql.Blob, ([] as Byte[]).class])) {
				return
			}
			dataTableCols << [
				key: "'" + p.name + "'",
				label: "'" + p.naturalName + "'",
				sortable: true,
				resizeable: true
			]
		}
		dataTableCols
	}
	
}