package com.bensmann.glue.auth

import java.util.UUID

/**
 * 
 */
class GlueUser {
	
	String name
	String password
	String apiKey
	
	static hasMany = [
		role: GlueRole
	]
	
	/**
	 * Before insert.
	 */
	def beforeInsert = {
		apiKey = generateApiKey()
	}
	
	/**
	 * Generate an API key.
	 */
	def static generateApiKey(arg) {
		UUID.randomUUID().toString()
	}
	
	static mapping = {
		table "T0_USER"
	}
	
	static constraints = {
		name(nullable: false)
		password(nullable: true)
		apiKey(nullable: true)
	}
	
	static glueConstraints = {
		glue {
			property(name: "role") {
				widget {
					component(test: "moreThan", value: 0, type: "list")
				}
				autoComplete true
			}
		}
	}
	
}