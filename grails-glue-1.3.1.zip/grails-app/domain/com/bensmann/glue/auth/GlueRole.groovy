package com.bensmann.glue.auth

/**
 * Authority domain class.
 */
class GlueRole {
	
	/**
	 * The name.
	 */
	String name
	
	/**
	 * ROLE String
	 */
	String roleName
	
	/**
	 * Description.
	 */
	String description
	
	static constraints = {
		name(nullable: false, unique: true)
		roleName(nullable: true)
		description(nullable: true)
	}
	
	static mapping = {
		table "T0_ROLE"
	}
	
}
