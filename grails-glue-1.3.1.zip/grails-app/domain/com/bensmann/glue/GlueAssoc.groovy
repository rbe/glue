package com.bensmann.glue

/**
 * Remember associations.
 */
class GlueAssoc {
	
	String domainA
	Long domainIdA
	String propertyA
	String domainB
	Long domainIdB
	Boolean active
	
	static constraints = {
		domainA(nullable: false)
		domainIdA(nullable: false)
		propertyA(nullable: false)
		domainB(nullable: false)
		domainIdB(nullable: false)
		active(nullable: false)
	}
	
	static mapping = {
		table "T0_ASSOC"
	}
	
}
