package com.bensmann.glue.context

import com.bensmann.glue.auth.*

/**
 * 
 */
class GlueContext {
	
	/**
	 * The user.
	 */
	GlueUser user
	
	/**
	 * The last session ID used with this context.
	 */
	String sessionId
	
	/**
	 * 
	 */
	String contextXml
	
	static constraints = {
		user(nullable: true, unique: true)
		sessionId(nullable: true, unique: true)
		contextXml(nullable: true, maxSize: 8000)
	}
	
	static mapping = {
		table "T0_CTX"
	}
	
}